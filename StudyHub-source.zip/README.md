# STUDYHUB

Website học tập tĩnh dành cho học sinh THPT. Toàn bộ trang được xây bằng HTML,
CSS và JavaScript thuần, không cần cài đặt, đăng nhập hay chạy máy chủ.

## Mở website

1. Giải nén `StudyHub-source.zip`.
2. Mở `index.html` bằng trình duyệt.
3. Dùng thanh điều hướng để chuyển giữa năm trang.

Các trang, tài liệu mẫu, hình minh họa, CSS và JavaScript đều nằm trong thư mục
này. Đường dẫn là tương đối để website có thể mở trực tiếp từ máy tính.

## Cấu trúc

- `index.html` — trang chủ
- `knowledge.html` — thư viện kiến thức, có tìm kiếm và lọc môn học
- `documents.html` — tài liệu mẫu có thể xem hoặc tải
- `quiz.html` — bài trắc nghiệm 10 câu
- `about.html` — giới thiệu và thông tin nhóm có thể chỉnh sửa
- `css/style.css` — giao diện và bố cục responsive
- `js/` — chức năng dùng chung, tìm kiếm/lọc và chấm điểm
- `images/` — hình minh họa SVG cục bộ
- `documents/` — các tài liệu mẫu HTML, Markdown và văn bản thuần

Thư viện hiện không có tệp PDF; định dạng thật của từng tài liệu được ghi rõ
trên trang Tài liệu. Có thể sửa tên và vai trò thành viên trong `about.html`.

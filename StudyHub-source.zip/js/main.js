// Điều hướng, giao diện sáng/tối và các tương tác dùng chung cho toàn trang.
(() => {
  const body = document.body;
  const themeButton = document.querySelector("[data-theme-toggle]");
  const menuButton = document.querySelector("[data-menu-toggle]");
  const nav = document.querySelector("[data-site-nav]");
  // Một số trình duyệt giới hạn bộ nhớ cục bộ khi mở tệp trực tiếp; giao diện vẫn dùng được nếu bị chặn.
  const readLocal = key => { try { return localStorage.getItem(key); } catch (_) { return null; } };
  const writeLocal = (key, value) => { try { localStorage.setItem(key, value); } catch (_) { /* Không làm gián đoạn trang khi bộ nhớ bị chặn. */ } };
  const savedTheme = readLocal("studyhub-theme");
  if (savedTheme === "dark") body.classList.add("dark");
  const updateThemeLabel = () => {
    if (!themeButton) return;
    const dark = body.classList.contains("dark");
    themeButton.setAttribute("aria-label", dark ? "Chuyển sang giao diện sáng" : "Chuyển sang giao diện tối");
    themeButton.setAttribute("title", dark ? "Giao diện sáng" : "Giao diện tối");
    themeButton.innerHTML = dark
      ? '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.8 14.2A8.5 8.5 0 0 1 9.8 3.2 8.6 8.6 0 1 0 20.8 14.2Z"/></svg>';
  };
  updateThemeLabel();
  themeButton?.addEventListener("click", () => {
    body.classList.toggle("dark");
    writeLocal("studyhub-theme", body.classList.contains("dark") ? "dark" : "light");
    updateThemeLabel();
  });
  menuButton?.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.setAttribute("aria-label", open ? "Đóng menu" : "Mở menu");
  });
  nav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton?.setAttribute("aria-expanded", "false");
  }));
  const current = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav a").forEach(link => {
    if (link.getAttribute("href") === current) link.setAttribute("aria-current", "page");
  });
  const toast = document.querySelector(".toast");
  document.querySelectorAll("[data-toast]").forEach(control => control.addEventListener("click", () => {
    if (!toast) return;
    toast.textContent = control.dataset.toast;
    toast.classList.add("show");
    window.setTimeout(() => toast.classList.remove("show"), 2400);
  }));
  // Lưu các chỉnh sửa hồ sơ nhóm cục bộ trên trình duyệt hiện tại.
  document.querySelectorAll("[data-editable]").forEach((field, index) => {
    const key = `studyhub-team-${index}`;
    const stored = readLocal(key);
    if (stored) field.textContent = stored;
    field.addEventListener("input", () => writeLocal(key, field.textContent.trim()));
  });
})();

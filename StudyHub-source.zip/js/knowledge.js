// Tìm kiếm và lọc thư viện kiến thức ngay trên dữ liệu tĩnh của trang.
(() => {
  const search = document.querySelector("#lesson-search");
  const filter = document.querySelector("#subject-filter");
  const cards = [...document.querySelectorAll("[data-lesson-card]")];
  const count = document.querySelector("#lesson-count");
  // Trang chủ có thể mở thư viện với sẵn từ khóa hoặc môn học.
  const params = new URLSearchParams(location.search);
  search.value = params.get("search") || "";
  const requestedSubject = params.get("subject");
  if (requestedSubject && [...filter.options].some(option => option.value === requestedSubject)) {
    filter.value = requestedSubject;
  }
  const normalize = value => value.toLocaleLowerCase("vi").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d");
  function update() {
    const term = normalize(search.value.trim());
    const subject = filter.value;
    let visible = 0;
    cards.forEach(card => {
      const matchesText = normalize(card.textContent).includes(term);
      const matchesSubject = subject === "all" || card.dataset.subject === subject;
      const show = matchesText && matchesSubject;
      card.hidden = !show;
      if (show) visible++;
    });
    count.textContent = `Đang hiển thị ${visible} bài học`;
    const empty = document.querySelector("#empty-lessons");
    empty.hidden = visible !== 0;
  }
  search.addEventListener("input", update);
  filter.addEventListener("change", update);
  update();
})();

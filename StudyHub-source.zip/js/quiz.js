// Chấm bài trắc nghiệm phía trình duyệt, hiện đáp án và cho phép làm lại.
(() => {
  const form = document.querySelector("#quiz-form");
  if (!form) return;
  const questions = [...form.querySelectorAll("[data-question]")];
  const result = document.querySelector("#quiz-result");
  const scoreLabel = document.querySelector("#quiz-score");
  const feedback = document.querySelector("#quiz-feedback");
  const progress = document.querySelector("#quiz-progress");
  const submit = document.querySelector("#quiz-submit");
  const updateProgress = () => {
    const answered = questions.filter(question => question.querySelector("input:checked")).length;
    progress.textContent = `${answered}/${questions.length}`;
  };
  form.addEventListener("change", updateProgress);
  form.addEventListener("submit", event => {
    event.preventDefault();
    let score = 0;
    let unanswered = 0;
    questions.forEach(question => {
      const correct = question.dataset.answer;
      const selected = question.querySelector("input:checked");
      question.querySelectorAll(".answer-option").forEach(label => {
        label.classList.remove("correct-answer", "wrong-answer");
        const input = label.querySelector("input");
        if (input.value === correct) label.classList.add("correct-answer");
        if (selected && input.checked && input.value !== correct) label.classList.add("wrong-answer");
      });
      if (!selected) unanswered++;
      else if (selected.value === correct) score++;
    });
    scoreLabel.textContent = `${score}/${questions.length}`;
    feedback.textContent = unanswered
      ? `Bạn chưa trả lời ${unanswered} câu. Đáp án đúng được tô xanh để bạn ôn lại.`
      : score === questions.length ? "Xuất sắc — bạn đã nắm vững các kiến thức nền tảng!" : "Hãy xem lại các đáp án được tô xanh rồi thử sức lần nữa nhé.";
    result.classList.add("visible");
    result.setAttribute("tabindex", "-1");
    result.focus();
    submit.textContent = "Chấm lại bài";
  });
  document.querySelector("#quiz-reset").addEventListener("click", () => {
    form.reset();
    questions.forEach(question => question.querySelectorAll(".answer-option").forEach(label => label.classList.remove("correct-answer", "wrong-answer")));
    result.classList.remove("visible");
    submit.textContent = "Nộp bài và xem kết quả";
    updateProgress();
    document.querySelector("#quiz-title").focus();
  });
})();

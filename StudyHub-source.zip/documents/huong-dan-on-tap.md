# HƯỚNG DẪN ÔN TẬP HIỆU QUẢ

Tài liệu mẫu do STUDYHUB biên soạn để học sinh có thể tải và sử dụng ngoại tuyến. Đây là tệp Markdown văn bản thuần, không phải PDF.

## 1. Chia nhỏ mục tiêu

- Chọn một chủ đề cụ thể cho mỗi buổi học.
- Chia thời gian thành các phiên tập trung 25–35 phút, nghỉ ngắn giữa các phiên.
- Kết thúc buổi học bằng cách tự tóm tắt kiến thức mà không nhìn tài liệu.

## 2. Học chủ động

- Tự đặt câu hỏi trước khi đọc lời giải.
- Làm bài tập từ dễ đến khó và ghi lại lỗi sai.
- Ôn lại nội dung sau 1 ngày, 1 tuần và 1 tháng.

## 3. Ghi chép sau khi chữa bài

Với mỗi lỗi sai, hãy ghi: dạng bài, nguyên nhân, cách sửa và một ví dụ tương tự. Đừng chỉ chép đáp án.

## 4. Lịch mẫu trong một buổi tối

| Thời lượng | Hoạt động |
| --- | --- |
| 30 phút | Ôn công thức Toán và làm 3 bài tập |
| 10 phút | Nghỉ, vận động nhẹ |
| 30 phút | Đọc lại ghi chú Vật lý, tự giải thích khái niệm |
| 20 phút | Ôn từ vựng tiếng Anh bằng câu ví dụ |

Hãy điều chỉnh lịch theo sức khỏe, thời khóa biểu và mục tiêu cá nhân.
